#include <stdio.h>
#include <stdlib.h> 	

int main() 
{
	for(int x=1; x <= 20;){
		printf("%d\n",x);
		x=x+1;
	}
	return 0;
}a
