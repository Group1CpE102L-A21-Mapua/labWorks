#include <stdio.h>
#include <stdlib.h> 	

int main() 
{
	int n = 1;
	int n2 = 1;
	int n3 = 1;
	int trip;
	int doub;
	while(n <= 20){
		printf("%d\n\n",n);
		n=n+1;
	}
	while(n2 <= 20){
		doub = n2 * 2;
		printf("%d\n\n",doub);
		n2=n2+1;
	}
	while(n3 <= 20){
		trip = n3 * 3;
		printf("%d\n\n",trip);
		n3=n3+1;
	}
	return 0;
}
